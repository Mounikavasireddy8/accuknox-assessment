import requests
import time

def check_application_status(url):
    try:
        # Send a GET request to the application URL
        response = requests.get(url, timeout=5)
        
        # Check the HTTP status code
        if response.status_code == 200:
            return "up"
        else:
            return f"down (HTTP {response.status_code})"
    except requests.exceptions.RequestException as e:
        # Handle exceptions (e.g., connection errors, timeouts)
        return f"down ({str(e)})"

def main():
    # Replace with your application's URL
    app_url = "https://example.com"
    
    # Check the application status
    status = check_application_status(app_url)
    
    # Print the result
    print(f"Application is {status}")

if __name__ == "__main__":
    main()