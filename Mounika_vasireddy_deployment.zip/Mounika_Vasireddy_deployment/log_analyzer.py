import re
from collections import Counter

log_data = [
    '192.168.1.1 - - [01/Sep/2022:12:34:56 +0000] "GET /index.html HTTP/1.1" 200 1234',
    '192.168.1.1 - - [01/Sep/2022:12:34:57 +0000] "GET /style.css HTTP/1.1" 404 0',
    '192.168.1.1 - - [01/Sep/2022:12:34:58 +0000] "GET /script.js HTTP/1.1" 200 5678',
    '192.168.1.1 - - [01/Sep/2022:12:34:59 +0000] "GET /image.jpg HTTP/1.1" 404 0',
    '192.168.1.1 - - [01/Sep/2022:12:35:00 +0000] "GET /index.html HTTP/1.1" 200 1234',
]

pattern = r' 404 '
error_count = sum(1 for line in log_data if re.search(pattern, line))

pages = [line.split()[6] for line in log_data]
page_counts = Counter(pages)

print(f"Number of 404 errors: {error_count}")
print("Most requested pages:")
for page, count in page_counts.most_common(5):
    print(f"{page}: {count} requests")